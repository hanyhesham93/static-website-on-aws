Bucket website endpoint: http://my-776169933250-bucket.s3-website-us-east-1.amazonaws.com

Distribution domain name: d2xmbpmwxx7aol.cloudfront.net